// frontend/src/SentimentAnalysis.js
import React, { useState } from 'react';

const SentimentAnalysis = () => {
  const [text, setText] = useState('');
  const [result, setResult] = useState(null);

  const analyzeText = async () => {
    const response = await fetch('http://localhost:4000/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    const data = await response.json();
    setResult(data);
  };

  return (
    <div>
      <h2>Аналіз настроїв</h2>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Введіть текст для аналізу"
        rows="5"
        cols="50"
      />
      <br />
      <button onClick={analyzeText}>Аналізувати</button>
      {result && (
        <div>
          <h3>Результат:</h3>
          <pre>{JSON.stringify(result, null, 2)}</pre>
        </div>
      )}
    </div>
  );
};

export default SentimentAnalysis;
