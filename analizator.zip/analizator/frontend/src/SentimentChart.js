// frontend/src/SentimentChart.js
import React, { useEffect, useState } from 'react';
import Plotly from 'plotly.js-basic-dist';

const SentimentChart = () => {
  const [data, setData] = useState([0, 0, 0]);

  useEffect(() => {
    // Отримання збережених постів із backend
    fetch('http://localhost:4000/api/posts')
      .then(res => res.json())
      .then(posts => {
        const sentimentCount = { Positive: 0, Negative: 0, Neutral: 0 };
        posts.forEach(post => {
          if(post.sentiment) {
            sentimentCount[post.sentiment] += 1;
          }
        });
        setData([sentimentCount.Positive, sentimentCount.Negative, sentimentCount.Neutral]);
      });
  }, []);

  useEffect(() => {
    const chartData = [
      {
        x: ['Positive', 'Negative', 'Neutral'],
        y: data,
        type: 'bar'
      }
    ];
    Plotly.newPlot('chart', chartData);
  }, [data]);

  return (
    <div>
      <h2>Графік аналізу настроїв</h2>
      <div id="chart"></div>
    </div>
  );
};

export default SentimentChart;
