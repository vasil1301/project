// frontend/src/App.js
import React from 'react';
import SentimentAnalysis from './SentimentAnalysis';
import SentimentChart from './SentimentChart';

function App() {
  return (
    <div>
      <h1>Аналіз тексту соціальних мереж</h1>
      <SentimentAnalysis />
      <SentimentChart />
    </div>
  );
}

export default App;
